﻿using System;
namespace CicekSepetiAlgoritma.ENUMS
{
    public enum BayiMaxMin
    {
        KIRMIZI=0,YESIL=1,MAVI=2
    }
}
