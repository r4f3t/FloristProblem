﻿using System;
namespace CicekSepetiAlgoritma.Models
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
