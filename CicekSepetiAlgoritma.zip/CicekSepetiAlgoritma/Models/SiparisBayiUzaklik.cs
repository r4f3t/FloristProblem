﻿using System;
namespace CicekSepetiAlgoritma.Models
{
    public class SiparisBayiUzaklik
    {
        public int SiparisKodu { get; set; }
        public Bayi Bayi { get; set; }
        public double Uzaklik { get; set; }
    }
}
