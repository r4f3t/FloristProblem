﻿using System;
namespace CicekSepetiAlgoritma.Models
{
    public class Siparis
    {

        public int SiparisKod { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }

    }
}
